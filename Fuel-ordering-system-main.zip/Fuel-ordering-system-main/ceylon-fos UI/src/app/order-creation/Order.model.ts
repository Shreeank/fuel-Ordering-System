export interface Order {
    NIC: string,
    amount: number
}