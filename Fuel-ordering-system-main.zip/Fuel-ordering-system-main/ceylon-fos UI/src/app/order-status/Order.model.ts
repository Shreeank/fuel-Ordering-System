export interface Order {
    NIC: string,
    amount: number,
    uniqueKey: string,
    status: string,
    time: string
}