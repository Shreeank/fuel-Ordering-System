export const Event = {
    from: String,
    type: String,
    key: String,
    result: String
  }