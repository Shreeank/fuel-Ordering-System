export interface Dispatch {
    NIC: string
    amount: number
    uniqueKey: string
    status: string
    scheduledDate: string
    time: string
}