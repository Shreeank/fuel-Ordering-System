export interface Order {
    NIC: string
    uniqueKey: string
    amount: number
    status: string
    time: string
}